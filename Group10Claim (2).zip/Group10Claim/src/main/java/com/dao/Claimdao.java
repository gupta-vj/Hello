package com.dao;
import com.model.Ticket;
import com.model.Users;
import com.model.Gr10_Policies;
import java.sql.ResultSet;  
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;  
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;  
 
  
public class Claimdao {  
JdbcTemplate template;  
public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
}   
public int saveTicket(Ticket r,int uid){  
	    List<Gr10_Policies> lst=show(uid);
	    Gr10_Policies grp=new Gr10_Policies();
	    grp=lst.get(0);
	    int pol=grp.getPolicy_id();
	    int status=grp.getPolicy_status();
    String query="insert into gr10_Ticket values('"+r.getTicket_no()+"','"+pol+"','"+status+"')"; 
   return  template.update(query);  
}  
public String check(int uid) {
    String query = "select * from Users where id="+uid; 
    List<Users> users =template.query(query, new UserMapper());
    return users.size() > 0 ? "successful" : "No such User";
}
public List<Gr10_Policies> show(int uid) {
    String query = "select * from gr10_policies where User_id="+uid; 
    List<Gr10_Policies> u =template.query(query, new Gr10_PoliciesMapper());
    return u;
}
class UserMapper implements RowMapper<Users> {
	  public Users mapRow(ResultSet rs, int arg1) throws SQLException {
	    Users user = new Users();
	    user.setId(rs.getInt("id"));
	    user.setAge(rs.getInt("age"));
	    user.setName(rs.getString("name"));
	    user.setContact(rs.getLong("contact"));
	    user.setEmail(rs.getString("email"));
	    user.setPassword(rs.getString("password"));
	    return user;
	  }
	}
class Gr10_PoliciesMapper implements RowMapper<Gr10_Policies> {
	  public Gr10_Policies mapRow(ResultSet rs, int arg1) throws SQLException {
		  Gr10_Policies p = new Gr10_Policies();
	    p.setPolicy_id(rs.getInt("policy_id"));
	    p.setVehicle_id(rs.getInt("vehicle_id"));
	    p.setPolicy_type(rs.getString("vehicle_id"));
	    p.setPolicy_status(rs.getInt("policy_status"));
	    p.setRegistration_no(rs.getInt("registration_no"));
	    p.setChasis_no(rs.getInt("chasis_no"));
	    p.setRegistration_no(rs.getInt("registration_no"));
	    p.setEngine_no(rs.getInt("engine_no"));
	    p.setClaim_amount(rs.getInt("claim_amount"));
	    p.setUser_id(rs.getInt("user_id"));
	    return p;
	  }
	}
  
   
}  
