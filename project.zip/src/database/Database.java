package database;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
	static  Connection conn = null;
	private  Database(){

	}
	public static Connection getDBConnection(){
		try{

			/*DRIVER="com.mysql.jdbc.Driver";  
	CONNECTION_URL="jdbc:mysql://localhost:3306/DB Name";  
	USERNAME="DB Username";  
	PASSWORD="DB Password";*/
			//Load and register the JDBC driver.
			Class.forName("com.mysql.jdbc.Driver");
			//Open a connection to the database.
		    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vijayproject?useSSL=false", "root", "");
		
		    //Class.forName("oracle.jdbc.OracleDriver");
			//conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:vijayproject","System","Newuser123");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
}
