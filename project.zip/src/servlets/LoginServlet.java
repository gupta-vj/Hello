package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import database.Database;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		try {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String userName = request.getParameter("emails");
		String password = request.getParameter("pass");
		Connection conn = Database.getDBConnection();
		String SelectQuery = "SELECT * FROM users WHERE Email=? AND Password=?";
		PreparedStatement ps = conn.prepareStatement(SelectQuery);
		ps.setString(1, userName);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
			HttpSession session = request.getSession(true);
			session.setAttribute("UserId", rs.getString("UserId"));
			session.setAttribute("UserName", rs.getString("Name"));
			session.setAttribute("UserEmailId", rs.getString("Email"));
			session.setAttribute("UserMobileNo", rs.getString("MobileNo"));
			session.setAttribute("UserGender", rs.getString("Gender"));
			session.setAttribute("UserDOB", rs.getString("DOB"));
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
		else{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Invaild Username And Password!!!');");
			out.println("location = 'login.jsp';");
			out.println("</script>");
		}
		rs.close();
		ps.close();
		conn.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
