package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.Database;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		try {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			String userName = request.getParameter("name");
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			String gender = request.getParameter("gender");
			String dobs = request.getParameter("dob");
			String password = request.getParameter("pass");
			Connection conn = Database.getDBConnection();
			System.out.println("dob "+dobs);
			String SelectQuery = "SELECT * FROM users WHERE Email=?";
			PreparedStatement ps = conn.prepareStatement(SelectQuery);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			if(!rs.next()){
				String InsertQuery = "INSERT INTO users (Name,Email,MobileNo,Password,Gender,DOB) VALUES(?,?,?,?,?,?)";
				ps = conn.prepareStatement(InsertQuery);
				ps.setString(1, userName);
				ps.setString(2, email);
				ps.setString(3, phone);
				ps.setString(4, password);
				ps.setString(5, gender);
				ps.setString(6, dobs);
				ps.executeUpdate();
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
			else{
				out.println("<script type=\"text/javascript\">");
				out.println("alert('User Already Exists!!!');");
				out.println("location = 'Register.jsp';");
				out.println("</script>");
			}
			rs.close();
			ps.close();
			conn.close();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	}

}
